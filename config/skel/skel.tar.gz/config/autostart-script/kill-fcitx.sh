#!/bin/bash

sleep 10
killall fcitx
